package modules;

import java.util.*;
import jetbrick.template.JetContext;
import jetbrick.template.runtime.*;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast"})
public final class index_jetx extends JetPage {

  @Override
  public void render(final JetPageContext $ctx) throws Throwable {
    final JetContext context = $ctx.getContext();
    final JetWriter $out = $ctx.getWriter();
    Object ctxpath = (Object) context.get("ctxpath");
    $out.print($txt_1, $txt_1_bytes);
    JetUtils.asInclude($ctx, "/common/common-head.jetx", (Map<String, Object>)null); // line: 4
    $out.print($txt_2, $txt_2_bytes);
    JetUtils.asInclude($ctx, "/common/top.jetx", (Map<String, Object>)null); // line: 8
    $out.print($txt_3, $txt_3_bytes);
    $out.print(ctxpath); // line: 17
    $out.print($txt_4, $txt_4_bytes);
    $out.print(ctxpath); // line: 37
    $out.print($txt_5, $txt_5_bytes);
    $out.print($txt_6, $txt_6_bytes);
    $out.print($txt_7, $txt_7_bytes);
    $out.print($txt_6, $txt_6_bytes);
    $out.print($txt_9, $txt_9_bytes);
    JetUtils.asInclude($ctx, "/common/footer.jetx", (Map<String, Object>)null); // line: 44
    $out.print($txt_10, $txt_10_bytes);
    JetUtils.asInclude($ctx, "/common/common-bottom.jetx", (Map<String, Object>)null); // line: 47
    $out.print($txt_11, $txt_11_bytes);
    $out.flush();
  }

  @Override
  public String getName() {
    return "/modules/index.jetx";
  }

  public static final String $ENC = "UTF-8";
  private static final String $txt_1 = "<!DOCTYPE html>\r\n<html>\r\n<head>\r\n";
  private static final byte[] $txt_1_bytes = JetUtils.asBytes($txt_1, $ENC);
  private static final String $txt_2 = "</head>\r\n\r\n<body>\r\n";
  private static final byte[] $txt_2_bytes = JetUtils.asBytes($txt_2, $ENC);
  private static final String $txt_3 = "\r\n\t<div class=\"jumbotron masthead\" id=\"content\">\r\n\t\t<div class=\"container\">\r\n\t\t\t<h1>XDOC!</h1>\r\n\t\t\t<p>XDOC 是一套自动接口发布系统，支持多语言的接口自动化发布。 通过简单的录入过程，就可以获得项目的接口发布列表和文档。</p>\r\n\t\t\t<p>您也可以订阅感兴趣的项目，获取它的最新动态、变更信息</p>\r\n\t\t\t<p>\r\n\t\t\t\t<a class=\"btn btn-large btn-success\" role=\"button\"\r\n\t\t\t\t\thref=\"";
  private static final byte[] $txt_3_bytes = JetUtils.asBytes($txt_3, $ENC);
  private static final String $txt_4 = "/web/project/index\">进入项目列表 </a>\r\n\t\t\t</p>\r\n\t\t</div>\r\n\t</div>\r\n\r\n\t<div class=\"container\">\r\n\t\t<div class=\"row\">\r\n\t\t\t<div class=\"span6\">\r\n\t\t\t\t<h2>由来</h2>\r\n\t\t\t\t<p>场景1 \"没有提供完整的接口文档\"</p>\r\n\t\t\t\t<p>场景2 \"接口怎么老是变动！\"</p>\r\n\t\t\t\t<p>场景3 \"现在还在开发中，不稳定！\"</p>\r\n\t\t\t\t<p>场景4 \"怎么又改了！\"</p>\r\n\t\t\t\t<p>类似的情况是不是经常发生？XDOC为此而生</p>\r\n\t\t\t</div>\r\n\t\t\t<div class=\"span6\">\r\n\t\t\t\t<h2>模板下载</h2>\r\n\t\t\t\t<p>三种语言的代码模板供开发使用</p>\r\n\t\t\t\t<p>\r\n\t\t\t\t\t<a class=\"btn btn-default\"\r\n\t\t\t\t\t\thref=\"";
  private static final byte[] $txt_4_bytes = JetUtils.asBytes($txt_4, $ENC);
  private static final String $txt_5 = "/download/java-eclipse.zip\" role=\"button\">JAVA模板&raquo;</a>\r\n\t\t\t\t\t<a class=\"btn btn-default\" href=\"";
  private static final byte[] $txt_5_bytes = JetUtils.asBytes($txt_5, $ENC);
  private static final String $txt_6 = "#";
  private static final byte[] $txt_6_bytes = JetUtils.asBytes($txt_6, $ENC);
  private static final String $txt_7 = "\" role=\"button\">JS模板&raquo;</a>\r\n\t\t\t\t\t<a class=\"btn btn-default\" href=\"";
  private static final byte[] $txt_7_bytes = JetUtils.asBytes($txt_7, $ENC);
  private static final String $txt_9 = "\" role=\"button\">C++模板&raquo;</a>\r\n\t\t\t\t</p>\r\n\t\t\t</div>\r\n\t\t</div>\r\n\r\n";
  private static final byte[] $txt_9_bytes = JetUtils.asBytes($txt_9, $ENC);
  private static final String $txt_10 = "\t</div>\r\n\r\n";
  private static final byte[] $txt_10_bytes = JetUtils.asBytes($txt_10, $ENC);
  private static final String $txt_11 = "</body>\r\n</html>";
  private static final byte[] $txt_11_bytes = JetUtils.asBytes($txt_11, $ENC);
}
