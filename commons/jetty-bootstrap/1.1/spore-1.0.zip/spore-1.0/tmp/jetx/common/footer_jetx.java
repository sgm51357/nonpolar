package common;

import java.util.*;
import jetbrick.template.JetContext;
import jetbrick.template.runtime.*;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast"})
public final class footer_jetx extends JetPage {

  @Override
  public void render(final JetPageContext $ctx) throws Throwable {
    final JetContext context = $ctx.getContext();
    final JetWriter $out = $ctx.getWriter();
    $out.print($txt_1, $txt_1_bytes);
    $out.flush();
  }

  @Override
  public String getName() {
    return "/common/footer.jetx";
  }

  public static final String $ENC = "UTF-8";
  private static final String $txt_1 = "<hr>\n<footer>\n\t<p>&copy; 海康威视公安事业部 2014</p>\n</footer>";
  private static final byte[] $txt_1_bytes = JetUtils.asBytes($txt_1, $ENC);
}
