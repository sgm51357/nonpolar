package common;

import java.util.*;
import jetbrick.template.JetContext;
import jetbrick.template.runtime.*;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast"})
public final class common_002dbottom_jetx extends JetPage {

  @Override
  public void render(final JetPageContext $ctx) throws Throwable {
    final JetContext context = $ctx.getContext();
    final JetWriter $out = $ctx.getWriter();
    Object ctxpath = (Object) context.get("ctxpath");
    $out.print($txt_1, $txt_1_bytes);
    $out.print(ctxpath); // line: 1
    $out.print($txt_2, $txt_2_bytes);
    $out.print(ctxpath); // line: 2
    $out.print($txt_3, $txt_3_bytes);
    $out.print(ctxpath); // line: 3
    $out.print($txt_4, $txt_4_bytes);
    $out.print(ctxpath); // line: 5
    $out.print($txt_5, $txt_5_bytes);
    $out.print(ctxpath); // line: 9
    $out.print($txt_6, $txt_6_bytes);
    $out.flush();
  }

  @Override
  public String getName() {
    return "/common/common-bottom.jetx";
  }

  public static final String $ENC = "UTF-8";
  private static final String $txt_1 = "<script type=\"text/javascript\" src=\"";
  private static final byte[] $txt_1_bytes = JetUtils.asBytes($txt_1, $ENC);
  private static final String $txt_2 = "/view/components/bootstrap/2.3.2/js/bootstrap.js\"></script>\r\n<script type=\"text/javascript\" src=\"";
  private static final byte[] $txt_2_bytes = JetUtils.asBytes($txt_2, $ENC);
  private static final String $txt_3 = "/view/components/jquery/plugins/validform/Validform_v5.3.2_min.js\"></script>\r\n<script type=\"text/javascript\" src=\"";
  private static final byte[] $txt_3_bytes = JetUtils.asBytes($txt_3, $ENC);
  private static final String $txt_4 = "/view/components/jquery/plugins/xdialog/xDialog.min.js\"></script>\r\n<!--[if lte IE 6]>\r\n<script type=\"text/javascript\" src=\"";
  private static final byte[] $txt_4_bytes = JetUtils.asBytes($txt_4, $ENC);
  private static final String $txt_5 = "/view/components/bootstrap/ie/js/bootstrap-ie6.js\"></script>\r\n<![endif]-->\r\n<!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->\r\n<!-- [if lt IE 9]\r\n<script src=\"";
  private static final byte[] $txt_5_bytes = JetUtils.asBytes($txt_5, $ENC);
  private static final String $txt_6 = "/view/js/html5shiv.min.js\"></script>\r\n<![endif]-->";
  private static final byte[] $txt_6_bytes = JetUtils.asBytes($txt_6, $ENC);
}
