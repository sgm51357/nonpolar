package common;

import java.util.*;
import jetbrick.template.JetContext;
import jetbrick.template.runtime.*;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast"})
public final class top_jetx extends JetPage {

  @Override
  public void render(final JetPageContext $ctx) throws Throwable {
    final JetContext context = $ctx.getContext();
    final JetWriter $out = $ctx.getWriter();
    Object ctxpath = (Object) context.get("ctxpath");
    $out.print($txt_1, $txt_1_bytes);
    $out.print(ctxpath); // line: 12
    $out.print($txt_2, $txt_2_bytes);
    $out.print(ctxpath); // line: 15
    $out.print($txt_3, $txt_3_bytes);
    $out.print(ctxpath); // line: 18
    $out.print($txt_4, $txt_4_bytes);
    $out.print(ctxpath); // line: 24
    $out.print($txt_5, $txt_5_bytes);
    $out.print($txt_6, $txt_6_bytes);
    $out.print($txt_7, $txt_7_bytes);
    $out.print($txt_6, $txt_6_bytes);
    $out.print($txt_9, $txt_9_bytes);
    $out.print($txt_10, $txt_10_bytes);
    $out.print($txt_11, $txt_11_bytes);
    $out.print($txt_6, $txt_6_bytes);
    $out.print($txt_9, $txt_9_bytes);
    $out.print($txt_10, $txt_10_bytes);
    $out.print($txt_15, $txt_15_bytes);
    $out.print(ctxpath); // line: 35
    $out.print($txt_16, $txt_16_bytes);
    $out.print($txt_6, $txt_6_bytes);
    $out.print($txt_9, $txt_9_bytes);
    $out.print($txt_10, $txt_10_bytes);
    $out.print($txt_20, $txt_20_bytes);
    $out.print($txt_6, $txt_6_bytes);
    $out.print($txt_9, $txt_9_bytes);
    $out.print($txt_23, $txt_23_bytes);
    $out.print($txt_24, $txt_24_bytes);
    $out.print($txt_6, $txt_6_bytes);
    $out.print($txt_9, $txt_9_bytes);
    $out.print($txt_10, $txt_10_bytes);
    $out.print($txt_28, $txt_28_bytes);
    $out.print(ctxpath); // line: 41
    $out.print($txt_16, $txt_16_bytes);
    $out.print($txt_6, $txt_6_bytes);
    $out.print($txt_9, $txt_9_bytes);
    $out.print($txt_10, $txt_10_bytes);
    $out.print($txt_33, $txt_33_bytes);
    $out.flush();
  }

  @Override
  public String getName() {
    return "/common/top.jetx";
  }

  public static final String $ENC = "UTF-8";
  private static final String $txt_1 = "<div class=\"navbar navbar-inverse navbar-fixed-top\">\n\t<div class=\"navbar-inner\">\n\t\t<div class=\"container\">\n\t\t\t<button type=\"button\" class=\"btn btn-navbar\" data-toggle=\"collapse\" data-target=\".nav-collapse\">\n\t\t\t\t<span class=\"icon-bar\"></span>\n\t\t\t\t<span class=\"icon-bar\"></span>\n\t\t\t\t<span class=\"icon-bar\"></span>\n\t\t\t</button>\n\t\t\t<div class=\"nav-collapse collapse\">\n\t\t\t\t<ul class=\"nav\">\n\t\t\t\t\t<li class=\"\">\n\t\t\t\t\t\t<a href=\"";
  private static final byte[] $txt_1_bytes = JetUtils.asBytes($txt_1, $ENC);
  private static final String $txt_2 = "/web/welcome/index\">XDOC</a>\n\t\t\t\t\t</li>\n\t\t\t\t\t<li class=\"\">\n\t\t\t\t\t\t<a href=\"";
  private static final byte[] $txt_2_bytes = JetUtils.asBytes($txt_2, $ENC);
  private static final String $txt_3 = "/web/project/index\">项目</a>\n\t\t\t\t\t</li>\n\t\t\t\t\t<li class=\"\">\n\t\t\t\t\t\t<a href=\"";
  private static final byte[] $txt_3_bytes = JetUtils.asBytes($txt_3, $ENC);
  private static final String $txt_4 = "/web/relation/index\">关系图</a>\n\t\t\t\t\t</li>\n\t\t\t\t</ul>\n\t\t\t\t<div class=\"navbar-form pull-right\">\n\t\t\t\t\t<input type=\"text\" id=\"projectName\" placeholder=\"项目搜索\">\n\t\t\t\t\t<button class=\"btn\" type=\"button\" id=\"search\">搜索</button>\n\t\t\t\t\t<a class=\"btn btn-default\" href=\"";
  private static final byte[] $txt_4_bytes = JetUtils.asBytes($txt_4, $ENC);
  private static final String $txt_5 = "/web/projects/new\">创建新项目</a>\n\t\t\t\t</div>\n\t\t\t</div>\n\t\t</div>\n\t</div>\n</div>\n<script type=\"text/javascript\">\n\t";
  private static final byte[] $txt_5_bytes = JetUtils.asBytes($txt_5, $ENC);
  private static final String $txt_6 = "$";
  private static final byte[] $txt_6_bytes = JetUtils.asBytes($txt_6, $ENC);
  private static final String $txt_7 = "(document).ready(function(){\n\t    ";
  private static final byte[] $txt_7_bytes = JetUtils.asBytes($txt_7, $ENC);
  private static final String $txt_9 = "(\'";
  private static final byte[] $txt_9_bytes = JetUtils.asBytes($txt_9, $ENC);
  private static final String $txt_10 = "#projectName";
  private static final byte[] $txt_10_bytes = JetUtils.asBytes($txt_10, $ENC);
  private static final String $txt_11 = "\').bind(\'keypress\', function(event){\n\t\t    if(event.keyCode == \"13\") {\n\t\t\t    if(";
  private static final byte[] $txt_11_bytes = JetUtils.asBytes($txt_11, $ENC);
  private static final String $txt_15 = "\').val() != null) {\n\t\t\t\t    window.location.href = \"";
  private static final byte[] $txt_15_bytes = JetUtils.asBytes($txt_15, $ENC);
  private static final String $txt_16 = "/web/projects/index?projectName=\" + ";
  private static final byte[] $txt_16_bytes = JetUtils.asBytes($txt_16, $ENC);
  private static final String $txt_20 = "\').val();\n\t\t\t    }\n\t\t    }\n\t    });\n\t    ";
  private static final byte[] $txt_20_bytes = JetUtils.asBytes($txt_20, $ENC);
  private static final String $txt_23 = "#search";
  private static final byte[] $txt_23_bytes = JetUtils.asBytes($txt_23, $ENC);
  private static final String $txt_24 = "\').click(function(){\n\t\t    if(";
  private static final byte[] $txt_24_bytes = JetUtils.asBytes($txt_24, $ENC);
  private static final String $txt_28 = "\').val() != null) {\n\t\t\t    window.location.href = \"";
  private static final byte[] $txt_28_bytes = JetUtils.asBytes($txt_28, $ENC);
  private static final String $txt_33 = "\').val();\n\t\t    }\n\t    });\n    });\n</script>";
  private static final byte[] $txt_33_bytes = JetUtils.asBytes($txt_33, $ENC);
}
