package common;

import java.util.*;
import jetbrick.template.JetContext;
import jetbrick.template.runtime.*;

@SuppressWarnings({"all", "warnings", "unchecked", "unused", "cast"})
public final class common_002dhead_jetx extends JetPage {

  @Override
  public void render(final JetPageContext $ctx) throws Throwable {
    final JetContext context = $ctx.getContext();
    final JetWriter $out = $ctx.getWriter();
    Object ctxpath = (Object) context.get("ctxpath");
    $out.print($txt_1, $txt_1_bytes);
    $out.print(ctxpath); // line: 9
    $out.print($txt_2, $txt_2_bytes);
    $out.print(ctxpath); // line: 9
    $out.print($txt_3, $txt_3_bytes);
    $out.print(ctxpath); // line: 10
    $out.print($txt_2, $txt_2_bytes);
    $out.print(ctxpath); // line: 10
    $out.print($txt_5, $txt_5_bytes);
    $out.print(ctxpath); // line: 11
    $out.print($txt_6, $txt_6_bytes);
    $out.print(ctxpath); // line: 12
    $out.print($txt_7, $txt_7_bytes);
    $out.print(ctxpath); // line: 13
    $out.print($txt_8, $txt_8_bytes);
    $out.print(ctxpath); // line: 14
    $out.print($txt_9, $txt_9_bytes);
    $out.print(ctxpath); // line: 15
    $out.print($txt_10, $txt_10_bytes);
    $out.print(ctxpath); // line: 16
    $out.print($txt_11, $txt_11_bytes);
    $out.print(ctxpath); // line: 18
    $out.print($txt_12, $txt_12_bytes);
    $out.print(ctxpath); // line: 21
    $out.print($txt_13, $txt_13_bytes);
    $out.print(ctxpath); // line: 23
    $out.print($txt_14, $txt_14_bytes);
    $out.flush();
  }

  @Override
  public String getName() {
    return "/common/common-head.jetx";
  }

  public static final String $ENC = "UTF-8";
  private static final String $txt_1 = "<!-- Meta, title, CSS, favicons, etc. -->\r\n<meta charset=\"utf-8\">\r\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\r\n<meta name=\"description\" content=\"xdoc - 接口发布系统\">\r\n<meta name=\"keywords\" content=\"Interface, XDOC\">\r\n<title>XDOC 接口发布系统</title>\r\n<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\" />\r\n<meta http-equiv=\"viewpoint\" content=\"width=device-width, initial-scale=1.0\" />\r\n<link rel=\"icon\" href=\"";
  private static final byte[] $txt_1_bytes = JetUtils.asBytes($txt_1, $ENC);
  private static final String $txt_2 = "/view/img/xdoc.ico\" mce_href=\"";
  private static final byte[] $txt_2_bytes = JetUtils.asBytes($txt_2, $ENC);
  private static final String $txt_3 = "/view/img/xdoc.ico\" type=\"image/x-icon\"/>\r\n<link rel=\"shortcut icon\" href=\"";
  private static final byte[] $txt_3_bytes = JetUtils.asBytes($txt_3, $ENC);
  private static final String $txt_5 = "/view/img/xdoc.ico\" type=\"image/x-icon\"/>\r\n<link rel=\"stylesheet\" type=\"text/css\" href=\"";
  private static final byte[] $txt_5_bytes = JetUtils.asBytes($txt_5, $ENC);
  private static final String $txt_6 = "/view/components/bootstrap/2.3.2/css/bootstrap.min.css\" />\r\n<link rel=\"stylesheet\" type=\"text/css\" href=\"";
  private static final byte[] $txt_6_bytes = JetUtils.asBytes($txt_6, $ENC);
  private static final String $txt_7 = "/view/components/bootstrap/2.3.2/css/bootstrap-responsive.min.css\" />\r\n<link rel=\"stylesheet\" type=\"text/css\" href=\"";
  private static final byte[] $txt_7_bytes = JetUtils.asBytes($txt_7, $ENC);
  private static final String $txt_8 = "/view/css/docs.css\" />\r\n<link rel=\"stylesheet\" type=\"text/css\" href=\"";
  private static final byte[] $txt_8_bytes = JetUtils.asBytes($txt_8, $ENC);
  private static final String $txt_9 = "/view/css/fonts.css\" />\r\n<link rel=\"stylesheet\" type=\"text/css\" href=\"";
  private static final byte[] $txt_9_bytes = JetUtils.asBytes($txt_9, $ENC);
  private static final String $txt_10 = "/view/css/prettify.css\" />\r\n<link rel=\"stylesheet\" type=\"text/css\" href=\"";
  private static final byte[] $txt_10_bytes = JetUtils.asBytes($txt_10, $ENC);
  private static final String $txt_11 = "/view/components/jquery/plugins/xdialog/xDialog.css\" />\r\n<!--[if lte IE 6]>\r\n<link rel=\"stylesheet\" type=\"text/css\" href=\"";
  private static final byte[] $txt_11_bytes = JetUtils.asBytes($txt_11, $ENC);
  private static final String $txt_12 = "/view/components/bootstrap/ie/css/bootstrap-ie6.css\">\r\n<![endif]-->\r\n<!--[if lte IE 7]>\r\n<link rel=\"stylesheet\" type=\"text/css\" href=\"";
  private static final byte[] $txt_12_bytes = JetUtils.asBytes($txt_12, $ENC);
  private static final String $txt_13 = "/view/components/bootstrap/ie/css/ie7.css\">\r\n<![endif]-->\r\n<script type=\"text/javascript\" src=\"";
  private static final byte[] $txt_13_bytes = JetUtils.asBytes($txt_13, $ENC);
  private static final String $txt_14 = "/view/components/jquery/jquery-1.8.3.min.js\"></script>\r\n";
  private static final byte[] $txt_14_bytes = JetUtils.asBytes($txt_14, $ENC);
}
